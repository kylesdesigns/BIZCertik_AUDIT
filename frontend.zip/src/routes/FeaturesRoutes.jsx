import FeaturesLayout from '../layout/FeaturesLayout';

import Features from '../pages/Features';

const FeaturesRoutes = {
  path: '/',
  element: <FeaturesLayout />,
  children: [
    {
      path: '/features',
      element: <Features />,
    },
  ],
};

export default FeaturesRoutes;
