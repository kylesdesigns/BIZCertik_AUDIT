import PartnerShipLayout from '../layout/PartnerShipLayout';
import Partnerships from '../pages/Partnerships';

const PartnerShipRoutes = {
  path: '/',
  element: <PartnerShipLayout />,
  children: [
    {
      path: '/partnerships',
      element: <Partnerships />,
    },
  ],
};

export default PartnerShipRoutes;
