import TradeLayout from '../layout/TradeLayout';
import Trade from '../pages/Trade';

const TradeRoutes = {
  path: '/',
  element: <TradeLayout />,
  children: [
    {
      path: '/trade',
      element: <Trade />,
    },
  ],
};

export default TradeRoutes;
