import { Box } from '@mui/material';
import styled from 'styled-components';

export const Title = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-size: 32px;
  line-height: 39px;
  text-align: center;
  margin-bottom: 100px;
  color: #000000;

  @media screen and (max-width: 710px) {
    /* flex-direction: column; */
    font-size: 30px;
  }
  @media screen and (max-width: 475px) {
    font-size: 24px;
  }
`;

export const ContentTitle = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-size: 28px;
  line-height: 39px;
  text-align: center;
  margin-bottom: 50px;
  color: #000000;

  @media screen and (max-width: 710px) {
    /* flex-direction: column; */
    font-size: 24px;
  }
  @media screen and (max-width: 475px) {
    font-size: 20px;
  }
`;

export const Main = styled(Box)`
  width: 100%;
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 29px;
  text-align: center;
  margin-bottom: 50px;

  @media screen and (max-width: 710px) {
    /* flex-direction: column; */
    font-size: 20px;
  }
  @media screen and (max-width: 475px) {
    font-size: 18px;
  }
`;

export const Content = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 25px;
  line-height: 120%;
  text-align: center;
  margin-bottom: 50px;
  color: #000000;

  @media screen and (max-width: 1000px) {
    width: 80%;
  }
  @media screen and (max-width: 900px) {
    width: 85%;
    font-size: 20px;
  }
  @media screen and (max-width: 710px) {
    width: 90%;
    font-size: 16px;
    margin-top: 36px;
  }
`;

export const StyledContainer = styled(Box)`
  padding: 270px 70px 70px 70px;
  width: 100vw;
  min-height: 100vh;

  @media screen and (max-width: 710px) {
    padding: 140px 40px 70px 40px;
  }
  position: relative;
`;

export const Background = styled(Box)`
  background-image: url('/images/features_back.png');
  background-repeat: no-repeat;
  background-size: 1728px 100%;
  background-position-x: 60%; //auto 100vh;
  position: absolute;
  margin-top: 200px;
  top: 0;
  left: 0;
  width: 100vw;
  height: 1177px;
  @media screen and (min-width: 1728px) {
    background-size: 100% 100%;
    height: calc(100vw / 1728 * 1177);
  }

  @media screen and (max-width: 900px) {
    background-size: 1296px 75%;
    background-position-y: 250px;
    height: calc(100vh - 200px);
  }

  @media screen and (max-width: 700px) {
    background-size: 864px 50%;
    background-position-y: 300px;
    height: calc(100vh - 200px);
  }
`;
