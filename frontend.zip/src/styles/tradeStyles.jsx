import { Box } from '@mui/material';
import styled from 'styled-components';

export const BackText = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 20px;
  line-height: 24px;

  color: #000000;
  margin-top: 4px;
`;

export const AdvancedText = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 18px;
  line-height: 22px;
  text-align: center;
  text-decoration-line: underline;

  color: #000000;
`;

export const AdvancedBox = styled(Box)`
  position: absolute;
  top: 65px;
  left: 50px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

export const IconBox = styled(Box)`
  position: absolute;
  top: 40px;
  right: 60px;
  opacity: 0.15;
`;

export const PowerBox = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 10px;
  line-height: 12px;

  color: #000000;
  position: absolute;
  bottom: 10px;
  left: 50%;
  transform: translate(-50%, 0);
`;

// export const TokenSymbol = styled(Box)``;

export const TokenSmallName = styled(Box)`
  font-family: 'DM Sans';
  font-style: normal;
  font-weight: 400;
  font-size: 15px;
  line-height: 20px;

  color: #000000;
`;

export const TokenName = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 30px;
  line-height: 36px;

  color: #000000;
  cursor: pointer;
`;

export const TradeDesc = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 22px;
  line-height: 27px;
  text-align: center;

  color: #000000;
`;

export const TradeText = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 22px;
  line-height: 27px;
  text-align: center;

  color: #000000;
  margin: 24px 0px;
`;

export const TradeHead = styled(Box)`
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 45px;
  line-height: 54px;
  text-align: center;

  color: #000000;
`;

export const TradeBox = styled(Box)`
  background: #fffcf1;
  opacity: 0.92;
  border: 1px solid #000000;
  box-shadow: inset 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 37px;
  flex-flow: column nowrap;
  width: fit-content;
  margin: auto;
  position: relative;
  max-width: 1240px;
  width: 100%;
`;

export const TradeChildBox = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;

export const TradeBottomBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-around;
`;

export const StyledContainer = styled(Box)`
  width: 100vw;
  min-height: 100vh;
  position: relative;
`;

export const Background = styled(Box)`
  background-image: url('/images/trade_back.png');
  background-repeat: no-repeat;
  background-size: 1728px 100%;
  background-position-x: 60%; //auto 100vh;
  margin-top: 200px;
  position: absolute;
  top: 0;
  left: 0;
  width: 100vw;
  height: 1177px;
  @media screen and (min-width: 1728px) {
    background-size: 100% 100%;
    height: calc(100vw / 1728 * 1177);
  }

  @media screen and (max-width: 900px) {
    background-size: 1296px 75%;
    background-position-y: 250px;
    height: calc(100vh - 200px);
  }

  @media screen and (max-width: 700px) {
    background-size: 864px 50%;
    background-position-y: 300px;
    height: calc(100vh - 200px);
  }
`;
