/* eslint-disable jsx-a11y/alt-text */
import { Box } from '@mui/material';
import { Title, ContentTitle, Content } from '../../styles/featuresStyles';

function FAQ() {
  return (
    <Box position={'relative'} width='100%'>
      <Title>FAQ</Title>
      <ContentTitle>Q: How does it work?</ContentTitle>
      <Content>
        Hikariswap is an OTC protocol that allows you to trade without slippage using our Private
        pools and lit markets.
      </Content>

      <ContentTitle>Q: What about Taxes and Fees from the pool tokens?</ContentTitle>

      <Content>
        We calculate transfer taxes and fees into the finalized price of your token output. If the
        token has no tax/slippage we can execute your order across our private pools and the open
        markets without the involvement of MEV bots.
      </Content>

      <ContentTitle>Q: How to use swap?</ContentTitle>

      <Content>
        You can go to our dapp and post your tokens up for a certain timeframe or a certain discount
        price. We match trades based on a FIFO basis. If you prioritize execution, we can also
        execute your orders over the lit markets with our algorithms.
      </Content>

      <ContentTitle>Q: What is TWAP and VWAP?</ContentTitle>

      <Content>
        These are our execution algorithms used on the backend - meaning Time Weighted Average Price
        and Volume Weighted Average Price respectively. We calculate the price impact, slippage, and
        gwei prices in order to divide your order into smaller ones to distribute across our pools
        for the best execution.
      </Content>

      <ContentTitle>Q: How does this benefit me?</ContentTitle>

      <Content>
        If you are a buyer, you can acquire your tokens for a lower price, if you are a seller you
        are able to reduce or exit your position with less market impact.
      </Content>

      <Content>
        If you are a token project, we help equip your community with a reliable way to buy and sell
        with minimal impact on your chart. This allows you to build long term trust and growth as
        you develop on your roadmap. Your team will also be able to materialize your treasury and
        pay salaries to your team and scale your business. You can apply for Hikari Pools here.
      </Content>

      <ContentTitle>Q: What is an OTC platform?</ContentTitle>

      <Content>
        OTC is over the counter trading, which means there will be no slippage on your tokens as a
        peer to peer transaction. Check our documentation here for more info.
      </Content>

      <ContentTitle>Q: Are the Hikariswap contracts audited?</ContentTitle>

      <Content>
        The contracts are in process of being audited, however we have battle tested this product
        since its inception in testnet.
      </Content>
    </Box>
  );
}

export default FAQ;
