import React from 'react';
import { Box, Stack, Typography, FormControl, TextField } from '@mui/material';

const DurationInput = ({ duration, onChangeDuration }) => {
  return (
    <Box
      sx={{
        width: '100%',
        mx: 0,
        mt: 1,
        py: 1,
        px: 2,
        // border: '1px solid #20242A',
        borderRadius: 3,
        background: '#f8eecd',
      }}
    >
      <Stack>
        {/* header */}
        <Stack>
          <Typography sx={{ fontSize: 12, color: 'gray' }}>Duration in Mins</Typography>
        </Stack>

        {/* input and quick time buttons*/}
        <Stack direction='row' display='flex' justifyContent='space-between'>
          <FormControl variant='standard'>
            <TextField
              inputProps={{
                inputMode: 'numeric',
                pattern: '[0-9]*',
              }}
              sx={{
                width: { xs: '70vw', md: '12em' },
                fontSize: 20,
                '& fieldset': { border: 'none' },
              }}
              value={duration}
              onChange={onChangeDuration}
            />
          </FormControl>
        </Stack>
      </Stack>
    </Box>
  );
};

export default DurationInput;
