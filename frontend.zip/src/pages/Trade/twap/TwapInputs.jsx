import {
  Box,
  Button,
  useMediaQuery,
  useTheme,
  Select,
  MenuItem,
  CircularProgress,
} from '@mui/material';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import ExpiresInInput from '../ExpiresInInput';
import BuyAmountInputs from './BuyAmountInputs';
import SellAmountInputs from './SellAmountInputs';
import DurationInput from '../DurationInput';
import { AiOutlineArrowRight } from 'react-icons/ai';

const TwapInputs = ({
  otcOrder,
  onChangeOtcOrder,
  listOrders,
  duration,
  onChangeDuration,
  buyAmount,
  onChangeBuyAmount,
  buyEveryX,
  onChangeBuyEveryX,
  sellAmount,
  onChnangeSellAmount,
  sellEveryX,
  onChangeSellEveryX,
  pending,
  handleCreateTwap,
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <Box
      sx={{
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        px: 0,
        py: 0,
        m: 0,
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <Select
          labelId='token-list-label'
          id='token-list'
          value={otcOrder ? otcOrder.orderId : 0}
          label='Twap Token'
          onChange={onChangeOtcOrder}
        >
          {listOrders.map((item, index) => (
            <MenuItem value={item.orderId} key={index}>
              {`${Number(item.sellTokenAmount)} ${item.sellTokenSymbol} => ${Number(
                item.buyTokenAmount,
              )} ${item.buyTokenSymbol}`}
            </MenuItem>
          ))}
        </Select>
      </Box>

      {/* Expires */}
      <Box
        sx={{
          width: '100%',
          mx: 0,
          mt: 1,
          py: 1,
          px: 2,
          // border: '1px solid #20242A',
          borderRadius: 3,
          background: '#f8eecd',
        }}
      >
        <DurationInput duration={duration} onChangeDuration={onChangeDuration} />
      </Box>

      <BuyAmountInputs
        hint={`${otcOrder.sellTokenAmount}`}
        buyHint={'Mins'}
        buyAmount={buyAmount}
        onChangeBuyAmount={onChangeBuyAmount}
        buyEveryX={buyEveryX}
        onChangeBuyEveryX={onChangeBuyEveryX}
      />
      {/* <SellAmountInputs
        hint={`${otcOrder.buyTokenAmount}`}
        sellHint={`Mins`}
        sellAmount={sellAmount}
        onChangedSellAmount={onChnangeSellAmount}
        onChangedSellEveryX={onChangeSellEveryX}
        sellEveryX={sellEveryX}
      /> */}

      <Box sx={{ display: 'flex', justifyContent: 'end', mt: 2, p: 0 }}>
        <Button
          variant='contained'
          sx={{
            background: '#B2B9D2',
            color: '#ffffff',
            borderRadius: 3,
            mx: 1,
          }}
          pending={(pending === false).toString()}
          onClick={handleCreateTwap}
          disabled={pending}
        >
          {!pending ? (
            <>
              Create
              <AiOutlineArrowRight />
            </>
          ) : (
            <>
              Create
              <AiOutlineArrowRight />
              <CircularProgress
                size={24}
                sx={{
                  position: 'absolute',
                  top: '50%',
                  left: '50%',
                  marginTop: '-12px',
                  marginLeft: '-12px',
                }}
              />
            </>
          )}
        </Button>
      </Box>
    </Box>
  );
};

export default TwapInputs;
