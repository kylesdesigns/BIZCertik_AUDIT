import { Box, MenuItem, Select, Button, CircularProgress } from '@mui/material';

import DurationInput from '../DurationInput';
import BuyInput from './BuyInput';
import { AiOutlineArrowRight } from 'react-icons/ai';

const VwapInputs = ({
  otcOrder,
  onChangeOtcOrder,
  listOrders,
  duration,
  onChangeDuration,
  buyAmount,
  onChangedBuyAmount,
  pending,
  handleCreateVwap,
}) => {
  // const theme = useTheme();
  // const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <Box
      sx={{
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        px: 0,
        py: 0,
        m: 0,
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <Select
          labelId='token-list-label'
          id='token-list'
          value={otcOrder ? otcOrder.orderId : 0}
          label='Twap Token'
          onChange={onChangeOtcOrder}
        >
          {listOrders.map((item, index) => (
            <MenuItem value={item.orderId} key={index}>
              {`${Number(item.sellTokenAmount)} ${item.sellTokenSymbol} => ${Number(
                item.buyTokenAmount,
              )} ${item.buyTokenSymbol}`}
            </MenuItem>
          ))}
        </Select>
      </Box>

      {/* Expires */}
      <Box
        sx={{
          width: '100%',
          mx: 0,
          mt: 1,
          py: 1,
          px: 2,
          // border: '1px solid #20242A',
          borderRadius: 3,
          background: '#f8eecd',
        }}
      >
        <DurationInput duration={duration} onChangeDuration={onChangeDuration} />
      </Box>

      <BuyInput buyAmount={buyAmount} onChangedBuyAmount={onChangedBuyAmount} />

      <Box sx={{ display: 'flex', justifyContent: 'end', mt: 2, p: 0 }}>
        <Button
          variant='contained'
          sx={{
            background: '#B2B9D2',
            color: '#ffffff',
            borderRadius: 3,
            mx: 1,
          }}
          pending={(pending === false).toString()}
          onClick={handleCreateVwap}
          disabled={pending}
        >
          {!pending ? (
            <>
              Create
              <AiOutlineArrowRight />
            </>
          ) : (
            <>
              Create
              <AiOutlineArrowRight />
              <CircularProgress
                size={24}
                sx={{
                  position: 'absolute',
                  top: '50%',
                  left: '50%',
                  marginTop: '-12px',
                  marginLeft: '-12px',
                }}
              />
            </>
          )}
        </Button>
      </Box>
    </Box>
  );
};

export default VwapInputs;
