import { useEffect, useState } from 'react';
import * as React from 'react';
import { styled, alpha } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { Box, CircularProgress, Stack } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import InputBase from '@mui/material/InputBase';
import { getTokenContract } from '../../utils/contracts';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import { toaster } from '../../utils/toast';
// Setup
import { Network, Alchemy } from 'alchemy-sdk';

const settings = {
  apiKey: 'Gpf3yQ_p-RMvz0w6isqvmipnpWR01VS-',
  network: Network.ETH_MAINNET,
};

const alchemy = new Alchemy(settings);

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));

function BootstrapDialogTitle(props) {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2, textAlign: 'center', height: '150px' }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label='close'
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
}

const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  backgroundColor: 'rgb(247, 247, 247)',
  borderRadius: '30px',
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  color: 'rgb(43, 113, 255)',
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  width: 'calc(100% - 90px)',
  padding: theme.spacing(1, 0),
  '& .MuiInputBase-input': {
    fontSize: '14px',
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    transition: theme.transitions.create('width'),
    width: '100%',
  },
}));

export const TokenModal = ({
  account,
  provider,
  open,
  setOpen,
  onSelect,
  tokenLT,
  sourceToken,
  targetToken,
}) => {
  const [tokenList, setTokenList] = useState(tokenLT || []);
  const [loading, setLoading] = useState(false);
  const [tokenKey, setTokenKey] = useState('all');

  const handleClose = () => {
    setOpen(false);
  };

  const handleOnchangeTokenKey = async (e) => {
    if (e.target.value === '') {
      setTokenKey('all');
    } else {
      setTokenKey(e.target.value);
    }
    if (e.target.value.indexOf('0x') !== -1) {
      const tokenContract = getTokenContract(e.target.value, provider.getSigner());
      if (tokenContract) {
        const tokensymbol = await tokenContract.symbol();
        const tokenname = await tokenContract.name();
        const tokenaddress = await tokenContract.address;
        const tokendecimals = await tokenContract.decimals();
        setTokenList([
          ...tokenList,
          {
            address: tokenaddress,
            name: tokenname,
            symbol: tokensymbol,
            decimals: tokendecimals,
          },
        ]);
      }
    }
  };

  const getTokenBalances = async () => {
    setLoading(true);
    // Get all outbound transfers for a provided address
    const balances = await alchemy.core.getTokenBalances(account);
    // Loop through all tokens with non-zero balance
    let newTokens = [...tokenLT];
    for (let token of balances.tokenBalances) {
      // Get balance of token
      let balance = token.tokenBalance;

      // Get metadata of token
      const metadata = await alchemy.core.getTokenMetadata(token.contractAddress);

      // Compute token balance in human-readable format
      balance = balance / Math.pow(10, metadata.decimals);
      balance = balance.toFixed(2);

      if (Number(balance) > 0) {
        if (metadata.symbol === 'ETH' || metadata.symbol === 'USDC') {
          newTokens = [
            {
              ...metadata,
              balance,
            },
            ...tokenLT.filter((item) => item.symbol !== metadata.symbol),
          ];
        } else {
          newTokens = [
            tokenLT.find((item) => item.symbol === 'ETH'),
            tokenLT.find((item) => item.symbol === 'USDC'),
            {
              ...metadata,
              balance,
            },
            ...tokenLT.filter(
              (item) =>
                item.symbol !== metadata.symbol && item.symbol !== 'ETH' && item.symbol !== 'USDC',
            ),
          ];
        }
      }
    }
    setTokenList(newTokens);
    setLoading(false);
  };

  const initTokens = () => {
    setTokenList(tokenLT);
  };

  useEffect(() => {
    tokenList.length === 0 && initTokens();
    // eslint-disable-next-line
  }, [tokenLT]);

  useEffect(() => {
    account && tokenLT.length > 0 && getTokenBalances();
    // eslint-disable-next-line
  }, [account, tokenLT]);

  return (
    <div>
      <BootstrapDialog onClose={handleClose} aria-labelledby='customized-dialog-title' open={open}>
        <Box
          sx={{
            width: '400px',
            height: '600px',
          }}
        >
          <BootstrapDialogTitle id='customized-dialog-title' onClose={handleClose}>
            <Box sx={{ fontSize: '24px', color: 'black', fontWeight: 'bold' }}>Select Token</Box>
            <Box sx={{ fontSize: '12px' }}>Search token by name, symbol or address</Box>
            <Search>
              <SearchIconWrapper>
                <SearchIcon />
              </SearchIconWrapper>
              <StyledInputBase
                placeholder='Search token by name, symbol or address'
                inputProps={{ 'aria-label': 'search' }}
                onChange={(e) => handleOnchangeTokenKey(e)}
              />
            </Search>
          </BootstrapDialogTitle>
          <DialogContent dividers sx={{ height: '450px', overflowY: 'auto' }}>
            <List dense sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
              {loading === true ? (
                <ListItem
                  sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                >
                  <CircularProgress />
                </ListItem>
              ) : (
                tokenList.map((tokenItem, index) => {
                  if (tokenKey !== 'all') {
                    if (
                      tokenKey.indexOf('0x') !== -1 &&
                      tokenItem?.address?.indexOf(tokenKey) === -1
                    ) {
                      return <></>;
                    } else if (
                      tokenKey.indexOf('0x') === -1 &&
                      tokenItem?.symbol?.indexOf(tokenKey) === -1
                    )
                      return <></>;
                  }
                  const labelId = `checkbox-list-secondary-label-${index}`;
                  return (
                    <ListItem key={index} sx={{ pl: 0, pr: 0 }}>
                      <ListItemButton
                        sx={{
                          backgroundColor: 'rgb(250, 250, 250)',
                          padding: '15px',
                          borderRadius: '15px',
                          justifyContent: 'space-between',
                        }}
                        onClick={() => {
                          setTokenKey('all');
                          if (tokenItem == sourceToken || tokenItem == targetToken)
                            toaster('error', 'Please connect your wallet');
                          else {
                            onSelect(tokenItem);
                            setOpen(false);
                          }
                        }}
                      >
                        <Stack direction={'row'} alignItems={'center'}>
                          <ListItemAvatar>
                            <Avatar
                              // sx={{ width: "25px", height: "25px" }}
                              alt={`Avatar n°${index + 1}`}
                              src={
                                tokenItem?.symbol === 'ETH'
                                  ? 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png'
                                  : tokenItem?.symbol === 'WAMPL'
                                  ? 'https://assets.coingecko.com/coins/images/20825/large/photo_2021-11-25_02-05-11.jpg?1637811951'
                                  : tokenItem?.symbol === 'UPI'
                                  ? 'https://assets.coingecko.com/coins/images/12186/large/pawtocol.jpg?1597962008'
                                  : tokenItem?.symbol === 'UNFI'
                                  ? 'https://assets.coingecko.com/coins/images/13152/large/logo-2.png?1605748967'
                                  : tokenItem?.symbol === 'MV'
                                  ? 'https://s2.coinmarketcap.com/static/img/coins/64x64/17704.png'
                                  : tokenItem?.symbol === 'ORCA'
                                  ? 'https://s2.coinmarketcap.com/static/img/coins/64x64/5183.png'
                                  : `https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/ethereum/assets/${tokenItem?.address}/logo.png`
                              }
                            />
                          </ListItemAvatar>
                          <ListItemText id={labelId} primary={`${tokenItem?.symbol}`} />
                        </Stack>
                        {tokenItem?.balance && (
                          <ListItemText
                            sx={{ overflow: 'hidden', textAlign: 'right' }}
                            id={labelId}
                            primary={`${Number(tokenItem?.balance).toFixed(5)}`}
                          />
                        )}
                      </ListItemButton>
                    </ListItem>
                  );
                })
              )}
            </List>
          </DialogContent>
        </Box>
      </BootstrapDialog>
    </div>
  );
};
