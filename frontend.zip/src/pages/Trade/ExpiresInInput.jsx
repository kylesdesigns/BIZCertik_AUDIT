import {
  Box,
  Container,
  FormControl,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { expirationTime } from '../../utils/content';

const ExpiresInInput = ({ expires, onChangedExpires, duration, onChangeDuration }) => {
  return (
    <Container
      sx={{
        display: { xs: 'block', md: 'flex' },
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        px: 1,
        py: 1,
      }}
    >
      <Box
        sx={{
          width: '100%',
          mx: 0,
          py: 1,
          px: 2,
          mt: -0.5,
          // border: '1px solid #20242A',
          borderRadius: 3,
          background: '#f8eecd',
        }}
      >
        <Stack>
          {/* header */}
          <Stack>
            <Typography sx={{ fontSize: 12, color: 'gray' }}>Expires in</Typography>
          </Stack>

          {/* input and quick time buttons*/}
          <Stack direction='row' display='flex' justifyContent='space-between'>
            <FormControl variant='standard'>
              <TextField
                inputProps={{
                  inputMode: 'numeric',
                  pattern: '[0-9]*',
                  placeholder: '1 hour',
                }}
                sx={{
                  // width: { xs: '70vw', md: '12em' },
                  fontSize: 20,
                  '& fieldset': { border: 'none' },
                }}
                fullWidth
                value={expires}
                onChange={onChangedExpires}
              />
            </FormControl>

            <Stack direction='row' spacing={1}>
              <Box display='flex' justifyContent='center' alignItems='center'>
                <Select
                  sx={{
                    fontSize: 20,
                    '& fieldset': { border: 'none' },
                  }}
                  value={duration}
                  onChange={onChangeDuration}
                >
                  {expirationTime.map((expires) => {
                    return (
                      <MenuItem value={expires.value} key={expires.title}>
                        {expires.title}
                      </MenuItem>
                    );
                  })}
                </Select>
              </Box>
            </Stack>
          </Stack>
        </Stack>
      </Box>
    </Container>
  );
};

export default ExpiresInInput;
