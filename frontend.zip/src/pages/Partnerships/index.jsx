/* eslint-disable jsx-a11y/alt-text */
import { Box, Link } from '@mui/material';
import { Title, Content } from '../../styles/partnershipStyles';

function Partnerships() {
  return (
    <Box position={'relative'} zIndex={10} width='100%'>
      <Title>Apply for Hikari Pools</Title>
      <Content>
        We allow your token pools to be utilized and to prevent slippage in your chart price for
        your seller, buyers, and large traders.
      </Content>
      <Content>
        Apply for Hikari Pools{' '}
        <Link
          href={'https://hikariswap.io/trade'}
          style={{ textDecoration: 'none', color: '#0093C1' }}
        >
          here
        </Link>
        .
      </Content>
    </Box>
  );
}

export default Partnerships;
