import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';
import { Background, StyledContainer } from '../styles/partnershipStyles';

const PartnerShipLayout = ({ children }) => {
  return (
    <StyledContainer>
      <Background />

      <Box sx={{ display: 'flex' }}>{!children && <Outlet />}</Box>
    </StyledContainer>
  );
};

export default PartnerShipLayout;
