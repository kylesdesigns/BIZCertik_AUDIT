import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';
import { tradePageBackgroundImage } from '../utils/content';

const TradeLayout = ({ children }) => {
  return (
    <Box
      sx={{
        padding: { md: '270px 70px 70px 70px', xs: '27px 7px 7px 7px' },
      }}
    >
      {/* <Background /> */}

      <Box>
        {/* Background */}
        <Box
          sx={{
            position: 'fixed',
            zIndex: -10,
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `url(${tradePageBackgroundImage})`,
            backgroundRepeat: 'no-repeat',
            height: '100vh',
            width: '100vw',
            backgroundPosition: `right bottom`,
            backgroundSize: `100vw 100vh`,
            objectFit: 'cover',
          }}
        />
        {/* Content */}
        <Box>{!children && <Outlet />}</Box>
      </Box>
    </Box>
  );
};

export default TradeLayout;
