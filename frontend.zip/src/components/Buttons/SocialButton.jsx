import { Link } from '@mui/material';
import styled from 'styled-components';

export const Socials = styled(Link)`
  margin: 0 37px 0 0 !important;
  text-decoration: none;
  font-size: 30px;
  color: black !important;
`;
