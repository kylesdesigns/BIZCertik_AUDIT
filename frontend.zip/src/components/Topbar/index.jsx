/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react';
import {
  useMediaQuery,
  AppBar,
  useTheme,
  Container,
  Stack,
  Typography,
  IconButton,
} from '@mui/material';
import { useAddress, useWeb3Context } from '../../hooks/web3Context';
import useScrollPosition from '../../hooks/useScrollPosition';
import { logo, navbarCenterLinks, navbarRightLinks } from '../../utils/content';
import NavbarLinkButton from '../Buttons/NavbarLinkButton';
import ConnectButton from '../Buttons/ConnectButton';
import DisconnectButton from '../Buttons/DisconnectButton';
import MenuIcon from '@mui/icons-material/Menu';
import Sidebar from './Sidebar';

function Topbar() {
  const scrollPosition = useScrollPosition();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('lg'));
  const [page, setPage] = useState('home');
  const account = useAddress();
  const { connect } = useWeb3Context();

  const [sidebarOpened, setSidebarOpened] = useState(false);

  const handleOpenSidebar = () => {
    setSidebarOpened(true);
  };

  const handleCloseSidebar = () => {
    setSidebarOpened(false);
  };

  useEffect(() => {
    setPage(window.location.href.slice(window.location.href.lastIndexOf('/') + 1));
  }, []);

  const connectWallet = () => {
    connect().then((msg) => {
      console.log(msg);
    });
  };

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        // addAccount({ id: accounts[0] })
        connectWallet();
      });
      window.ethereum.on('chainChanged', (chainId) => {
        window.location.reload();
      });
    }
    // eslint-disable-next-line
  }, [account]);

  return (
    <AppBar
      elevation={0}
      sx={{
        py: 1,
        height: 80,
        bgcolor: scrollPosition > 10 ? 'rgba(162, 185, 145, .4)' : 'transparent',
        backdropFilter: scrollPosition > 10 ? 'blur(60px)' : 'blur(0px)',
      }}
    >
      <Container>
        <Stack direction='row' alignItems='center' justifyContent='space-between' flexWrap='wrap'>
          {/* Logo */}
          <img src={logo} alt='brand logo' style={{ height: '100%', objectFit: 'contain' }} />

          {/* center links */}
          {!isMobile && (
            <Stack
              direction='row'
              alignItems='center'
              justifyContent='center'
              spacing={6}
              sx={{ flex: 1 }}
              flexWrap='wrap'
            >
              {navbarCenterLinks.map((link) => {
                return (
                  <NavbarLinkButton key={link.linkTo}>
                    <Typography
                      variant='body1'
                      onClick={() => window.open(link.linkTo, link.target)}
                      sx={{
                        color:
                          page !== link.linkTo.slice(link.linkTo.lastIndexOf('/') + 1).toLowerCase()
                            ? 'text.primary'
                            : '#0093C1',
                      }}
                    >
                      {link.title}
                    </Typography>
                  </NavbarLinkButton>
                );
              })}
            </Stack>
          )}

          {/* right links */}
          {isMobile ? (
            <IconButton onClick={handleOpenSidebar}>
              <MenuIcon sx={{ color: 'text.secondary' }} />
            </IconButton>
          ) : (
            <Stack
              direction='row'
              alignItems='center'
              justifyContent='center'
              spacing={6}
              flexWrap='wrap'
            >
              <>
                {navbarRightLinks.map((link) => {
                  return (
                    <NavbarLinkButton key={link.title}>
                      <Typography
                        variant='body1'
                        onClick={() => window.open(link.linkTo, link.target)}
                      >
                        {link.title}
                      </Typography>
                    </NavbarLinkButton>
                  );
                })}

                {/* Launch dApp */}
                {!account ? (
                  <ConnectButton
                    sx={{
                      height: 58,
                      width: 170,
                      color: 'text.primary',
                      borderColor: 'text.primary',
                      px: 2,
                    }}
                    onClick={() => {
                      connectWallet();
                    }}
                  />
                ) : (
                  <DisconnectButton
                    sx={{
                      height: 58,
                      width: 170,
                      color: 'text.primary',
                      borderColor: 'text.primary',
                      px: 2,
                    }}
                  />
                )}
              </>
            </Stack>
          )}
        </Stack>
      </Container>
      {/* sidebar */}
      <Sidebar
        isSidebarOpen={sidebarOpened}
        onOpen={handleOpenSidebar}
        onClose={handleCloseSidebar}
      />
    </AppBar>
  );
}

export default Topbar;
