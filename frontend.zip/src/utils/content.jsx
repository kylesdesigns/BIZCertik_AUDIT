import React from 'react';
import { FaTwitter, FaTelegramPlane } from 'react-icons/fa';
export const landingPageBackgroundImage = 'images/home_back.png';
export const logo = 'images/logo.png';
export const tradePageBackgroundImage = 'images/trade_back.png';

export const landingPageText = {
  title: 'HIKARI SWAP',
  subTitle: 'Trade with deep liquidity by utilizing our OTC pools and execution algorithms.',
};

export const socials = [
  {
    linkTo: 'https://t.me/hikaritoken',
    icon: <FaTelegramPlane size='35px' />,
  },
  { linkTo: ' https://twitter.com/HikariToken', icon: <FaTwitter size='35px' /> },
  {
    linkTo:
      'https://www.dextools.io/app/en/ether/pair-explorer/0xeb1e76957721a5a0d90345cd657a92e2942ead1d',
    icon: (
      <img src='/images/dex.png' alt='dextool logo' style={{ height: '35px', width: '35px' }}></img>
    ),
  },
  {
    linkTo: 'https://coinmarketcap.com/currencies/hikari-protocol/',
    icon: <img alt='coinmarketcap logo' src='/images/coinmarket.png'></img>,
  },
];

export const navbarCenterLinks = [
  {
    linkTo: '/',
    title: 'Home',
    target: '_self',
  },
  {
    linkTo: '/features',
    title: 'Features',
    target: '_self',
  },
  {
    linkTo: '/partnerships',
    title: 'Partnerships',
    target: '_self',
  },
  {
    linkTo: '/trade',
    title: 'Trade',
    target: '_self',
  },
  {
    linkTo: '/orders',
    title: 'Orders',
    target: '_self',
  },
];

export const navbarRightLinks = [
  {
    linkTo:
      'https://hikarilabs.gitbook.io/hikariswap-documentation/hikariswap/hikari-swap-overview',
    title: 'Docs',
    target: '_blank',
  },
  {
    linkTo: '/faq',
    title: 'FAQ',
    target: '_self',
  },
];

export const expirationTime = [
  {
    title: 'Hour',
    value: 60,
  },
  {
    title: 'Minutes',
    value: 1,
  },
  {
    title: 'Days',
    value: 1440,
  },
  {
    title: 'Weeks',
    value: 10080,
  },
  {
    title: 'Months',
    value: 43200,
  },
];

export const orderTableColumns = [
  { field: 'orderId', headerName: 'Order ID', minWidth: 50, align: 'left' },
  { field: 'sellTokenSymbol', headerName: 'Sell Token', minWidth: 90, align: 'right' },
  { field: 'sellTokenAddress', headerName: 'Token Sell Address', minWidth: 150, align: 'right' },
  { field: 'sellTokenAmount', headerName: 'Sell Amount', minWidth: 50, align: 'right' },
  { field: 'buyTokenSymbol', headerName: 'Buy Token', minWidth: 90, align: 'right' },
  { field: 'buyTokenAddress', headerName: 'Token Buy Address', minWidth: 150, align: 'right' },
  { field: 'buyTokenAmount', headerName: 'Buy Amount', minWidth: 50, align: 'right' },
];

export const defaultOTC = {
  buyAmount: '0',
  tokenInAddress: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  tokenInDecimals: 18,
  tokenOutAddress: '0xd4126f195a8de772eeffa61a4ab6dd43462f4e39',
  tokenOutDecimals: 18,
};

export const myTokens = [
  {
    name: 'Ethereum',
    address: '',
    symbol: 'ETH',
    logoURI:
      'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png',
  },
  {
    name: 'USDC',
    symbol: 'USDC',
    address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    logoURI:
      'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48/logo.png',
  },
  {
    name: 'HIKARI',
    symbol: 'HIKARI',
    address: '0xd4126f195a8de772eeffa61a4ab6dd43462f4e39',
    logoURI: '',
  },
];
