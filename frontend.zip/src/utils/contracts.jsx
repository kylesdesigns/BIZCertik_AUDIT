import { ContractFactory, ethers } from 'ethers';
import { HIKARI_ADDR } from '../abis/address';
import ERC20ABI from '../abis/ERC20ABI.json';
import HIKARIABI from '../abis/HIKARIABI.json';
import FactoryV2ABI from '../abis/IUniswapV2Factory.json';
import RouterV2ABI from '../abis/IUniswapV2Router02.json';
import PairV2ABI from '../abis/IUniswapV2Pair.json';
import UniswapV2TWAP from '../abis/UniswapV2TWAP.json';

// export const RPC_ENDPOINT =
//   "https://goerli.infura.io/v3/c154d90315a647ecace24c4afa8c1b3b";
// export const RPC_ENDPOINT = "https://rpc.ankr.com/eth_goerli";
// export const RPC_ENDPOINT = "https://rpc.ankr.com/eth";
export const RPC_ENDPOINT = process.env.REACT_APP_RPC_ENDPOINT;
// export const RPC_ENDPOINT =
//   "https://goerli.infura.io/v3/fa0f791c620c4507a1fe2d88c5fefe1b";

// Token Pair 0xAA5c3C23b99bE502e3D9Ab1D8540fF594ecf07dD
export const addresses = {
  adminAccount: process.env.REACT_APP_ADMIN_WALLET,
  // twapAddress: "0xFa3eCB75d38a4fD7Fa7B48BC7e8DB2319b5579dc",
  // token1: "0xe0B63ceC65dA5e0Dd84E49dD25EE8a0a5fC3D54f",
  // token2: "0xE366eCB27D3C29df9F286f1C67e5985A76389A33",
  factoryV2: process.env.REACT_APP_FACTORY_V2,
  // priceFeed: "0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419",
  routerV2: process.env.REACT_APP_ROUTER_V2,
  WETHV2: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
};

export const getContract = (abi, address, signer) => {
  const simpleRpcProvider = new ethers.providers.JsonRpcProvider(RPC_ENDPOINT);
  const signerOrProvider = signer ?? simpleRpcProvider;
  return new ethers.Contract(address, abi, signerOrProvider);
};

export const getTokenContract = (address, signer) => {
  return getContract(ERC20ABI, address, signer);
};

export const getHikariContract = (signer) => {
  return getContract(HIKARIABI, HIKARI_ADDR, signer);
};

export const getFactoryV2Contract = (signer) => {
  return getContract(FactoryV2ABI, addresses.factoryV2, signer);
};

export const getRouterV2Contract = (signer) => {
  return getContract(RouterV2ABI, addresses.routerV2, signer);
};

export const getPairV2Contract = (pairAddress, signer) => {
  return getContract(PairV2ABI, pairAddress, signer);
};

export const getV2OracleFactory = async (signer) => {
  const uniswapV2OracleFactory = new ContractFactory(
    UniswapV2TWAP.abi,
    UniswapV2TWAP.bytecode,
    signer,
  );
  return uniswapV2OracleFactory;
};

export const getV2OracleFactoryContract = (twapAddress, signer) => {
  return getContract(UniswapV2TWAP.abi, twapAddress, signer);
};

export const formatNumberToBigNumber = (amount, decimal) => {
  const rAmount = ethers.utils.parseUnits(`${amount}`, decimal);
  return rAmount;
};
