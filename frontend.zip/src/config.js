const localFlag = window.location.host.indexOf('localhost') === -1;
export const backendUrl = localFlag
  ? 'https://4jo9dla6t5.execute-api.us-east-1.amazonaws.com/api/'
  : 'http://localhost:4000/';
