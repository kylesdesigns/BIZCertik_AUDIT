import axios from 'axios';
import { backendUrl } from '../config';

export const cancelTVwap = async (type, orderID) => {
  const result = await axios.post(
    `${backendUrl}cancel_twap_vwap`,
    {
      type,
      orderID,
    },
    {
      'Content-Type': 'application/json',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'Deny',
      'Content-Security-Policy': "default-src 'self'",
    },
  );
  return result;
};
